from pynput.keyboard import Key, Listener
import logging

feels = False
#this is on_press use to identify keys
def on_press(key):
	global feels
	print(str(key))

	if(str(key).upper() =="KEY.ALT_L" and feels == True):
		print("Working")# here anything you can put later
	elif(feels == True and str(key) != "KEY.ALT_L"):
		feels = False
		print("Feels in last: ", feels)

	#This is first called to set feels true
	if(str(key).upper() == "KEY.CTRL_L"):
		feels = True
		print("Feels in top: ",feels)
	
#call this to start listen keys
def start():
	with Listener(on_press = on_press) as listener:
		listener.join()

#Key.ctrl_l
#Key.alt_l
