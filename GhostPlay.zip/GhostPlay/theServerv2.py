# first of all import the socket library 
import socket
import cGrabber as cbc      
import runVals as rv          
  
class server:

	def __init__(self):
		# next create a socket object 
		s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)          
		print ("Socket successfully created")

		port = rv.passw
		print("HOST", str(socket.gethostname()) )
		s.bind(("", port))         
		print ("socket binded to " , port )
		  
		# put the socket into listening mode 
		s.listen(5)      
		print ("socket is listening")
		  
		# a forever loop until we interrupt it or  
		# an error occurs 
		while rv.Listen == True: 
		  
			# Establish connection with client. 
			c, addr = s.accept()      
			print ('Got connection from', addr)  
			# send a thank you message to the client.  
			#c.send(bytes('Thank you for connecting',"utf-8")) 
			msg = str((c.recv(1024)).decode("utf-8"))
			#msg = str(c.recv(1024))
			print("Here in server : ", msg)
			# if(msg == "theBlackWakandaKindDiesFromCow"):
			# 	c.close()
			# 	break
			grab = cbc.cgrab(msg)
			#print ()
			 # Close the connection with the client 
			c.close() 


#Rememner to change the port number
