from kivy.app import App
from kivy.core.window import Window
from kivy.uix.label import Label
from kivy.uix.widget import Widget
from kivy.uix.image import Image
from kivy.config import Config
from kivy.lang import Builder
from kivy.uix.gridlayout import GridLayout
from kivy.uix.screenmanager import ScreenManager, Screen, NoTransition,FadeTransition
from kivy.properties import ObjectProperty
from kivy.properties import StringProperty
import hkeys
import qrmaker
import time
import tempDB as db
from autoStart import *
import main
import runVals as rv
import threading
import cTypeMod as ctm
import theServerv2 as serv


Config.set('graphics','resizable',False)
Config.set('graphics','width','1000')
Config.set('graphics','height','600')
Config.set('graphics', 'borderless', '1')
Config.set('kivy','exit_on_escape','1')

#Window Configuration
Window.borderless = 1
Window.size = (1000,600)
#qr maker in python calling qr marker in pip 
ip,passw = qrmaker.makeqrsecure()

rv.ip = ip
rv.passw = passw

# def servit():
# 	ss = serv.server()

# thread1 = threading.Thread(target = servit)
# thread1.start()z

#AutoStart, Minimize on start
iniValues = [False,False]
#Call the gui data in maingui madhe 
Builder.load_file("gui_data.kv")

# 0,1 = StartAI 2,3 StartCamp
startThingsList = ["","","",""]


class StartInitialization:
	theFileTxt = ""
	valList = [False,False]
				#0 = startAIText
				#1 = startTrainText


	def __init__(self):
		global startThingsList

		try:
			temp = db.getGUIValueByKey("homeCheckBox")
			self.convertToList((temp[1],temp[2]))	
		except:
			db.insertGUIValues("homeCheckBox","False","False","null","null")

		try:
			temp = db.getGUIValueByKey("startAIText")
			startThingsList[0] = temp[1]
			startThingsList[1] = temp[2]
		except:
			db.insertGUIValues("startAIText","CTRL","B","null","null")
			startThingsList[0] = "CTRL"
			startThingsList[1] = "B"

		try:
			temp = db.getGUIValueByKey("startTrainText")
			startThingsList[2] = temp[1]
			startThingsList[3] = temp[2]
		except:
			db.insertGUIValues("startTrainText","CTRL","V","null","null")
			startThingsList[2] = "CTRL"
			startThingsList[3] = "V"


	# This converts string values to boolean list
	def convertToList(self,ls):
		#valList = [False,False]
		for i in range(0,len(ls)):
			if ls[i] == "True":
				self.valList[i] = True
			else:
				self.valList[i] = False


	def initVals(self):
		#global valList
		print("Returning here now")
		return self.valList

# Making class object
bb = StartInitialization()
iniValues = bb.initVals()
print(iniValues)

# Kivy Classes
class Home(Screen):
	def func1():
		main.mainStart()
	a_start = ObjectProperty(iniValues[0])
	b_start = ObjectProperty(iniValues[1])
	rv.goAnCap = 1
	thread = threading.Thread(target = func1)
	thread.start()
	print("here are the magic")
	def checkAutoStart(self,instance,value):
		if value == True:
			createKey()
			iniValues[0] = True
			print(iniValues)
			print("Key Added")
		else:
			removeKey()
			iniValues[0] = False
			print("Key Removed")


	def checkMinimize(self,instance,value):
		if value == True:
			iniValues[1] = True
			print(iniValues)
			print("Minimize Added")
		else:
			iniValues[1] = False
			print("Minimize Removed")


	def close(self):
		exitApp(iniValues)
	def minimize(self):
		Window.minimize()

class Wifi(Screen):
	global ip
	def __init__(self, **kwargs):
		super(Wifi,self).__init__(**kwargs)
		self.add_widget(Label(text = ip ,pos = (-158,-197)))
		self.add_widget(Label(text = str(passw) ,pos = (145,-197)))

	def close(self):
		exitApp(iniValues)
	def minimize(self):
		Window.minimize()

class Hat(Screen):
	def close(self):
		exitApp(iniValues)
	def minimize(self):
		Window.minimize()

class Settings(Screen):
	global startThingsList

	startAIText = StringProperty(startThingsList[0]+ " + "+ startThingsList[1])
	startTrainText = StringProperty(startThingsList[2]+ " + "+ startThingsList[3])

	def changeAIHK(self):
		self.startAIText = "Press Hotkeys simulteneously"
		
	def callit(self,kw):
		hh = hkeys.HotkeyAssign(kw)
		print(kw)
		temp = db.getGUIValueByKey("startAIText")
		print("adasd " ,temp)
		if(kw == "AIText"):
			self.startAIText = str(temp[1])+ " + " + str(temp[2])
		elif(kw == "CampText"):
			self.startTrainText = str(temp[1])+ " + " + str(temp[2])

	def changeCampHK(self):
		self.startTrainText = "Press Hotkeys simulteneously"

	def close(self):
		exitApp(iniValues)
	def minimize(self):
		Window.minimize()

class Credits(Screen):
	def close(self):
		exitApp(iniValues)
	def minimize(self):
		Window.minimize()

class minApp:
	def __init__(self):
		main.mainStart()
		Window.minimize()

class exitApp:
	def __init__(self,ls):
		rv.Listen = False
		rv.goAnCap = 0
		db.updateGUIValueByKey("homeCheckBox",str(ls[0]),str(ls[1]),"null","null")
		ctm.PressKey("w")
		ctm.ReleaseKey("w")
		Window.close()
			

screen_manager = ScreenManager(transition = FadeTransition())
screen_manager.add_widget(Home(name = "home"))
screen_manager.add_widget(Wifi(name = "wifi"))
screen_manager.add_widget(Hat(name = "hat"))
screen_manager.add_widget(Settings(name = "settings"))
screen_manager.add_widget(Credits(name = "credits"))


class MainApp(App):
	def build(self):
		return screen_manager


# Kivy Class Object
if __name__ == '__main__':
	aa = MainApp()
	print(ip, passw)
	aa.run()