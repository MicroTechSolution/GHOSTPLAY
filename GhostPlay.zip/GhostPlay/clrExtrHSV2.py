from cv2 import *
import numpy as np
import tempDB as db
import runVals as rv

class colorExtractor:

	def cropFrame(self,frame):
		wid = 0
		hei = 0
		try:
			hei, wid = frame.shape[:]
			#if required 3 valuse
		except Exception:
			#print("here")
			wid,hei,_ = frame.shape[:]

		xValue = 100
		yValue = 200
		xCenter = int(wid/2);
		yCenter = int(hei/2);
		#cut here and return
		return frame[(xCenter-xValue):(xCenter+xValue), (yCenter-yValue): (yCenter + yValue)]
		
	def calculatePerson(self,frame,frameClr,minVal,maxVal):

		frame = cvtColor(frame,COLOR_BGR2HSV)
		frame = inRange(frame,minVal,maxVal)
		try:
			#coords = db.getValueByKey("clrExtrHSV_rectCoords")
			#here we need to raise exeption if runvals has -11
			if(rv.sCord1 == -1):
				raise ValueError("EmptyValues")
			
			coords = [rv.sCord1,rv.sCord2,rv.sCord3,rv.sCord4]


			#print("coords")
			#Center of (x,y) = new coords
			# x1 + x2 / 2 , y1 + y2 / 2
			newCoords = (int((int(coords[1])+int(coords[3]))/2),int((int(coords[2])+int(coords[4]))/2))
			result = self.checkAside(frame,newCoords)
			if result != [()]:
				#X1,y1,,x2,y2
				#db.updateValueByKey("clrExtrHSV_rectCoords",result[0][0],result[0][1],result[1][0],result[1][1])
				rv.sCord1 = result[0][0]
				rv.sCord2 = result[0][1]
				rv.sCord3 = result[1][0]
				rv.sCord4 = result[1][1]
				return result
			else:
				#reset to -1 in rv
				#db.deleteValueByKey("clrExtrHSV_rectCoords")
				rv.sCord1 = -1
				rv.sCord2 = -1
				rv.sCord3 = -1
				rv.sCord4 = -1
				#print("error result")
				#Here need to raise exception
				raise ValueError("error result")
			#print("here reached sucessfully")
			
		except:
			#print("!!!EXCEPT!!!")
			hei = 0
			wid=0
			startDots = (0,0)
			endDots = (0,0)
			currentDot=(0,0)
			try:
				hei, wid = frame.shape[:]
				#if required 3 valuse
			except Exception:
				hei,wid,_ = frame.shape[:]
			
			#frame = threshold(frame,225,255,THRESH_BINARY)
			for i in range(0, hei-1):
				for j in range(0, wid-1):
					#if i != hei-1 and j != wid-1:
					if frame[i,j] == 255:
						if currentDot != (0,0):
							currentDot = (i,j)
						else:
							startDots = (i,j)
							currentDot = (i,j)
					if i == (hei-2) and j == (wid-2):
						endDots = currentDot

			#print ("startDots: ",startDots)
			#print ("endDots",endDots)

			#frameClr = cvtColor(frameClr,COLOR_HSV2BGR)
			#rectangle(frameClr,(startDots[1],startDots[0]),(endDots[1],endDots[0]),(255,0,0),10)
			#db.insertValues("clrExtrHSV_rectCoords",startDots[0],startDots[1],endDots[0],endDots[1])

			rv.sCord1,rv.sCord2 = startDots
			rv.sCord3,rv.sCord4 = endDots


			#imshow("a",frameClr)
			#qwaitKey(0)
			#return ((startDots[0]+endDots[0])/2,(startDots[1]+endDots[1])/2)
			return (startDots,endDots)


	def checkAside(self,frame,coords):
		#Coords need = (x,y)
		steps = 40
		startDots = (0,0)
		endDots = (0,0)
		currentDot=(0,0)
		direction = 0
		
		for j in range(0,steps):
			for k in range(0,steps):
				
				#these are search areas
				#right down
				if(frame[coords[0]+j,coords[1] + k] == 255):
					currentDot = (coords[0]+j,coords[1]+k)
					break
				#right up
				elif(frame[coords[0]+j,coords[1] - k] == 255):
					currentDot = (coords[0]+j,coords[1]-k)
					break
					#left Down
				elif(frame[coords[0]-j,coords[1] - k] == 255):
					currentDot = (coords[0]+j,coords[1]-k)
					break
				#left up
				elif(frame[coords[0]-j,coords[1] + k] == 255):
					currentDot = (coords[0]-j,coords[1]+k)
					break
				
		# make a rectangle and return a frame
		if currentDot !=(0,0):
			return [(currentDot[0]-20,currentDot[1]-20),(currentDot[0]+20,currentDot[1]+20)]

		else:
			return [()]

	def midPoint(self,coords):
		return (int(coords[0][0]+coords[1][0])/2,int(coords[0][1]+coords[1][1])/2)
		

	def checkEnemy(self,frame,hei,wid):
		h,w,_ = frame.shape[:]
		print(w,h)
		heiOff = 40
		widOff = 60
		frame = frame[(int(h/2)-heiOff+40):(int(h/2)+heiOff+40),(int(w/2)-widOff):(int(w/2)+widOff)]
		frame = cvtColor(frame,COLOR_BGR2GRAY)
		tamplate = imread("res/tamplates/enemyTam.jpg",0)
		#w,h = tamplate.shape[::-1]
		res = matchTemplate(frame, tamplate, TM_CCOEFF_NORMED)
		threshold = 0.5
		loc = np.where(res >= threshold)
		if(str(loc[0]) == "[]"):
			return 0
		else:
			return 1


	def justToSeeMask(self,frame):
		frame = cvtColor(frame,COLOR_BGR2HSV)
		frame = inRange(frame,minVal,maxVal)
		return frame



if __name__ == '__main__':
	frame = imread("001.png")
	hei,wid,_ = frame.shape[:]
	#print(wid,hei)
	cc = colorExtractor()
	#imshow("aa",cc.checkEnemy(frame,frame,int(hei/2),int(wid/2)))
	#waitKey(0)
	print(cc.checkEnemy(frame,int(hei/2),int(wid/2)))
