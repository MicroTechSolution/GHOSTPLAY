from cv2 import *
import time
import numpy as np
import mouseMov as msm

class Navigation:

	def getWalkCoords(self,frame):
		self.hei,self.wid,_ = frame.shape[:]
		self.xCenter = int(self.wid/2)
		self.yCenter = int(self.hei/2)
		#previous Similar Value = 20
		frameCenter = frame[(self.yCenter-20)+100:(self.yCenter+20)+100,(self.xCenter-20):(self.xCenter+20)]
		count = self.countPixels(self.processFrame(frameCenter))
		# Navigation Values
		# 0 = fallback
		# 1 = go Straight
		# 2 = turn Left
		# 3 = turn Right
		if (count >= 300):
			frameLeft = frame[(self.yCenter-20)+100:(self.yCenter+20)+100,(self.xCenter-20)+200:(self.xCenter+20)+200]
			count = self.countPixels(self.processFrame(frameLeft))
			if(count >= 300):
				frameRight = frame[(self.yCenter-20)+100:(self.yCenter+20)+100,(self.xCenter-20)-200:(self.xCenter+20)-200]
				count = self.countPixels(self.processFrame(frameRight))
				if(count >= 300):
					return 0
				else:
					return 3
			else:
				return 2
		else:
			return 1


	#this one is working atleast
	def processFrame(self,frame):	
		minVal = np.array([24,49,100])
		maxVal = np.array([28,60,200])

		minVal2 = np.array([19,100,100])
		maxVal2 = np.array([21,120,300])


		minVal3 = np.array([38,30,100])
		maxVal3 = np.array([73,100,200])



		frame1 = cvtColor(frame,COLOR_BGR2HSV)
		frame1 = inRange(frame1,minVal,maxVal)

		frame2 = cvtColor(frame,COLOR_BGR2HSV)
		frame2 = inRange(frame2,minVal2,maxVal2)

		frame3 = cvtColor(frame,COLOR_BGR2HSV)
		frame3 = inRange(frame3,minVal3,maxVal3)

		frame = addWeighted(frame1,1,frame2,1,0)
		frame = addWeighted(frame,1,frame3,1,0)

		#imshow("as",frame)
		# if waitKey(1) & 0xFF == ord('q'):
		# 	break
		return frame



	def countPixels(self,frame):
		return np.sum(frame == 255)




if __name__ == '__main__':
	
	cap = VideoCapture("dima.mp4")

	while 1:
		_,frame = cap.read()
		#imshow("Frame",frame)
		if waitKey(1) & 0xFF == ord('q'):
			break
		nn = Navigation()
		nn.getWalkCoords(frame)
		#time.sleep(0.02)


