import pyqrcode
import socket
import random

def makeqr():
	stra = str(socket.gethostbyname(socket.gethostname()))
	q = pyqrcode.create(stra)
	q.png('res/myqr.png',scale = 15)
	print("Generated")

def makeqrsecure():
	ipAdd = socket.gethostbyname(socket.gethostname())
	theNum = random.randint(5000,9000)
	print(theNum)
	stra = str(ipAdd)+";"+ str(theNum)
	print(stra)
	q = pyqrcode.create(stra)
	q.png('res/myqr.png',scale = 15)
	print("Generated")
	print(theNum)
	return ipAdd,theNum

makeqrsecure()