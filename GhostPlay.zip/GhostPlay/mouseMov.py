from ctypes import *
import time
import win32gui

# see http://msdn.microsoft.com/en-us/library/ms646260(VS.85).aspx for details
def pos(x, y):
    windll.user32.SetCursorPos(x, y)

class POINT(Structure):
    _fields_ = [("x", c_long), ("y", c_long)]

def getMosuePos():
    pt = POINT()
    #print(windll.user32.GetCursorPos(byref(pt)))
    flags, hcursor, (x,y) = win32gui.GetCursorInfo()
    #return (pt.x,pt.y)
    return x,y

def click():
    #hex value required at 1st parameter
    #https://msdn.microsoft.com/en-us/library/windows/desktop/ms646260(v=vs.85).aspx
    windll.user32.mouse_event(0x0002, 0, 0, 0,0) # left down
    windll.user32.mouse_event(0x0004, 0, 0, 0,0) # left up

#From here we write outside usable fucntion

def rightClick():
    windll.user32.mouse_event(0x0008, 0, 0, 0,0) # right down
    windll.user32.mouse_event(0x0010, 0, 0, 0,0) # right up

def brustFire():
    for i in range(0,3):
        time.sleep(0.2)
        click()

def moveCursor(x1,y1):
    x,y = getMosuePos()
    pos(x + x1,y + y1)

def smoothDrag(newPosX,newPosY):
    x,y = getMosuePos()
    pos(newPosX,newPosY-30)

def halfRotLeft():
    x,y = getMosuePos()
    for i in range(4):
        pos(x+300,y) #set half of the screen
        time.sleep(0.02)
    #This is 90 degree


def halfRotRight():
    x,y = getMosuePos()
    for i in range(4):
        pos(x-300,y) #set half of the screen
        time.sleep(0.02)

def fullRotLeft(x,y):
    x,y = getMosuePos()
    for i in range(6):
        pos(x+500,y) #set half of the screen
        time.sleep(0.02)

def fullRotRight(x,y):
    x,y = getMosuePos()
    for i in range(6):
        pos(x-500,y) #set half of the screen
        time.sleep(0.02)


#time.sleep(3)
#smallRotLeft(1920,1080)
if __name__ == '__main__':
    print(getMosuePos())
