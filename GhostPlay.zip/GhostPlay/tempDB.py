from sqlite3 import *


def createTable():
	conn = connect('temp.db')
	c = conn.cursor()
	c.execute("""CREATE TABLE tempvals(
		key text,
		value1 text,
		value2 text,
		value3 text,
		value4 text
		)""")
	conn.commit()
	conn.execute()

def insertValues(key,val1,val2,val3,val4):
	try:
		createTable()
	except:
		pass

	conn = connect('temp.db')
	c = conn.cursor()
	exString = "insert into tempvals values('"+ str(key)+"','"+str(val1)+"','"+str(val2)+"','"+str(val3)+"','"+str(val4)+"')"
	#exString = "insert into tempvals values('hello','how','are','you','now')"
	c.execute(exString)
	conn.commit()
	conn.close()
	print("inserted ",str(key)," Sucessfully")

def deleteValueByKey(key):
	try:
		conn = connect('temp.db')
		c = conn.cursor()
		exString = "delete from tempvals where key == '"+str(key)+"'"
		c.execute(exString)
		conn.commit()
		conn.close()
		print("deleted ", str(key)," Sucessfully")
	except:
		print("Failed to delete key ", str(key))
		raise ValueError("Delete error")

def getValueByKey(key):
	try:
		conn = connect('temp.db')
		c = conn.cursor()
		exString = "select * from tempvals where key == '"+ str(key)+"'"
		c.execute(exString)
		conn.commit()
		a = c.fetchall()
		conn.close()
		print(a[0])
		return (a[0])
	except Exception as e:
		print("Failed to fetch values from database where key is ", str(key))
		raise ValueError("fetch Value error")

def updateValueByKey(key,val1,val2,val3,val4):
	try:
		conn = connect('temp.db')
		c = conn.cursor()
		exString = "update tempvals set value1 ='"+str(val1)+"',value2 = '"+str(val2)+"',value3 = '"+str(val3)+"',value4 = '"+str(val4)+"' where key == '"+str(key)+"'"
		c.execute(exString)
		conn.commit()
		conn.close()
		print("Updated ", str(key)," Sucessfully")
	except Exception as e:
		print("Failed to update values from database where key is ", str(key))
		raise ValueError("Update Failed")


##GUI

def createGUITable():
	conn = connect('temp.db')
	c = conn.cursor()
	c.execute("""CREATE TABLE guivals(
		key text,
		value1 text,
		value2 text,
		value3 text,
		value4 text
		)""")
	conn.commit()
	conn.execute()

def insertGUIValues(key,val1,val2,val3,val4):
	try:
		createGUITable()
	except:
		pass

	conn = connect('temp.db')
	c = conn.cursor()
	exString = "insert into guivals values('"+ str(key)+"','"+str(val1)+"','"+str(val2)+"','"+str(val3)+"','"+str(val4)+"')"
	#exString = "insert into tempvals values('hello','how','are','you','now')"
	c.execute(exString)
	conn.commit()
	conn.close()
	print("inserted ",str(key)," Sucessfully")

def deleteGUIValueByKey(key):
	try:
		conn = connect('temp.db')
		c = conn.cursor()
		exString = "delete from guivals where key == '"+str(key)+"'"
		c.execute(exString)
		conn.commit()
		conn.close()
		print("deleted ", str(key)," Sucessfully")
	except:
		print("Failed to delete key ", str(key))
		raise ValueError("Delete error")

def getGUIValueByKey(key):
	try:
		conn = connect('temp.db')
		c = conn.cursor()
		exString = "select * from guivals where key == '"+ str(key)+"'"
		c.execute(exString)
		conn.commit()
		a = c.fetchall()
		conn.close()
		print(a[0])
		return (a[0])
	except Exception as e:
		print("Failed to fetch values from database where key is ", str(key))
		raise ValueError("fetch Value error")

def updateGUIValueByKey(key,val1,val2,val3,val4):
	try:
		conn = connect('temp.db')
		c = conn.cursor()
		exString = "update guivals set value1 ='"+str(val1)+"',value2 = '"+str(val2)+"',value3 = '"+str(val3)+"',value4 = '"+str(val4)+"' where key == '"+str(key)+"'"
		c.execute(exString)
		conn.commit()
		conn.close()
		print("Updated ", str(key)," Sucessfully")
	except Exception as e:
		print("Failed to update values from database where key is ", str(key))
		raise ValueError("Update Failed")

def showAll():
	try:
		conn = connect('temp.db')
		c = conn.cursor()
		exString = "select * from guivals"
		c.execute(exString)
		conn.commit()
		a = c.fetchall()
		conn.close()
		print(a)
	except:
		print("Failed to fetch values from database")
		


if __name__ == "__main__":
	#insertValues("hello","qwe","try","das","fhfh")
	#deleteValueByKey("startAIText")
	deleteGUIValueByKey("startAIText")
	#insertValues("hello","qwe","try","das","fhfh")
	#updateValueByKey("hello","val1","val2","val3","val4")
	showAll()
	#getGUIValueByKey("homeCheckBox")
	# a = getValueByKey("Bello")
	# print(a)