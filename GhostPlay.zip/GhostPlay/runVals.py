#Here are all values used in runtime

ip = "192.168.0.101"
passw = 5000

isShooting = False
startCapV = 0
startAI = False
startCamp = False
Listen = True

isAIOn = False
isCampOn = False


# x1,y1,x2,y2
#default -1
sCord1 = -1
sCord2 = -1
sCord3 = -1
sCord4 = -1