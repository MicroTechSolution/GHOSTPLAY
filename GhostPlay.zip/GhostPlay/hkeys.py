from pynput import keyboard
from time import sleep
import tempDB as db
import runVals as rv

#string and combinations are need to come from database
#functions need to work on it also need to come from database

class HotkeyAssign:

	keyword = ""

	COMBINATIONS = [
        {"KEY.CTRL_L","\\X01"},
		{"KEY.CTRL_L","A"},
        {"KEY.CTRL_L","\\X02"},
		{"KEY.CTRL_L","B"},
        {"KEY.CTRL_L","\\X03"},
		{"KEY.CTRL_L","C"},
        {"KEY.CTRL_L","\\X04"},
		{"KEY.CTRL_L","D"},
        {"KEY.CTRL_L","\\X05"},
		{"KEY.CTRL_L","E"},
        {"KEY.CTRL_L","\\X06"},
		{"KEY.CTRL_L","F"},
        {"KEY.CTRL_L","\\X07"},
		{"KEY.CTRL_L","G"},
        {"KEY.CTRL_L","\\X08"},
		{"KEY.CTRL_L","H"},
        {"KEY.CTRL_L","\\X09"},
		{"KEY.CTRL_L","I"},
        {"KEY.CTRL_L","\\X10"},
		{"KEY.CTRL_L","J"},
        {"KEY.CTRL_L","\\X11"},
		{"KEY.CTRL_L","K"},
        {"KEY.CTRL_L","\\X12"},
		{"KEY.CTRL_L","L"},
        {"KEY.CTRL_L","\\X13"},
		{"KEY.CTRL_L","M"},
        {"KEY.CTRL_L","\\X14"},
		{"KEY.CTRL_L","N"},
        {"KEY.CTRL_L","\\X15"},
		{"KEY.CTRL_L","O"},
        {"KEY.CTRL_L","\\X16"},
		{"KEY.CTRL_L","P"},
        {"KEY.CTRL_L","\\X17"},
		{"KEY.CTRL_L","Q"},
        {"KEY.CTRL_L","\\X18"},
		{"KEY.CTRL_L","R"},
        {"KEY.CTRL_L","\\X19"},
		{"KEY.CTRL_L","S"},
        {"KEY.CTRL_L","\\X20"},
		{"KEY.CTRL_L","T"},
        {"KEY.CTRL_L","\\X21"},
		{"KEY.CTRL_L","U"},
        {"KEY.CTRL_L","\\X22"},
		{"KEY.CTRL_L","V"},
        {"KEY.CTRL_L","\\X23"},
		{"KEY.CTRL_L","W"},
        {"KEY.CTRL_L","\\X24"},
		{"KEY.CTRL_L","X"},
        {"KEY.CTRL_L","\\X25"},
		{"KEY.CTRL_L","Y"},
        {"KEY.CTRL_L","\\X26"},
		{"KEY.CTRL_L","Z"},
		]
	current = set()

	def __init__(self,keyword):
		self.keyword = keyword
		with keyboard.Listener(on_press = self.on_press, on_release = self.on_release) as listener:
			listener.join()


	def execute(self,a):
		print(a, " is detected")

		if(self.keyword == "AIText"):
			db.updateGUIValueByKey("startAIText","CTRL",str(a),"null","null")
		elif(self.keyword == "CampText"):
			db.updateGUIValueByKey("startTrainText","CTRL",str(a),"null","null")
		

	def on_press(self,key):
		key = str(key).replace("'","").upper()
		if any([key in COMBO for COMBO in self.COMBINATIONS]):
			self.current.add(key)
			if any(all(k in self.current for k in COMBO) for COMBO in self.COMBINATIONS):
				self.execute(key)
				self.on_release(key)
				return False

	def on_release(self,key):
		key = str(key).replace("'","").upper()
		if any([key in COMBO for COMBO in self.COMBINATIONS]):
			self.current.remove(key)


class HotKeyMonitor:

	keyFinder = ["a","a"]
	COMBINATIONS = [{"KEY.CTRL_L"},{"KEY.CTRL_L"}]

	current = set()
	def __init__(self):
		self.getKeys()
		sleep(2)
		with keyboard.Listener(on_press = self.on_press, on_release = self.on_release) as listener:
			listener.join()


	def getKeys(self):
		temp = db.getGUIValueByKey("startAIText")
		self.COMBINATIONS[0].add(str(temp[2]))
		self.keyFinder[0] = str(temp[2])
		temp = db.getGUIValueByKey("startTrainText")
		self.COMBINATIONS[1].add(str(temp[2]))
		self.keyFinder[1] = str(temp[2])
		print(self.keyFinder)

	def execute(self,a):
		if(self.keyFinder.index(a) == 0):
			rv.startAI ^= True
			rv.startCamp = False
		elif(self.keyFinder.index(a) == 1):
			rv.startAI = False
			rv.startCamp ^= True
		
		print(rv.startAI)

	def on_press(self,key):
		
		key = str(key).replace("'","").upper()
		if any([key in COMBO for COMBO in self.COMBINATIONS]):
			self.current.add(key)
			if any(all(k in self.current for k in COMBO) for COMBO in self.COMBINATIONS):
				self.execute(key)
		if(rv.goAnCap == 0):
			return False

	def on_release(self,key):
		key = str(key).replace("'","").upper()
		if any([key in COMBO for COMBO in self.COMBINATIONS]):
			self.current.remove(key)

# hk = HotKeyMonitor()