from cv2 import *
import clrExtrHSV2 as extr
import mouseMov as msm
import cTypeMod as ctm
import numpy as np
import runVals as rv
from time import sleep
import threading

class shoot:
	def __init__(self, frame,hei,wid):
		minVal = np.array([45,40,60])
		maxVal = np.array([55,120,120])
		cc = extr.colorExtractor()
		
		xCenter = int(wid/2) 
		yCenter = int(hei/2)
		#imshow("a",frame)
		#waitKey(0)
		vals = cc.midPoint(cc.calculatePerson(frame,frame,minVal,maxVal))
		#print(vals)

		if vals[0] != 0.0:
			rv.isShooting = True
			print("$$$ working $$$")
			ctm.ReleaseKey("w")
			
			coords = ((xCenter-100)+vals[0],(yCenter-200)+vals[1])
			print(coords)
			msm.smoothDrag(int(coords[1]),int(coords[0]))
			#imshow("as",frame)
			w,h,_ = frame.shape[::-1]
			frame = cvtColor(frame,COLOR_BGR2RGB)
			#waitKey(0)
			if(cc.checkEnemy(frame,int(w/2),int(h/2)) == 1):
				msm.brustFire()

		else:
			sleep(4)
			rv.isShooting = False

	def sleepit():
		sleep(4)
		rv.isShooting = False

def roi(frame,x1,y1,x2,y2):
	return frame[x1:x2,y1:y2]

# if __name__ == '__main__':
# 	frame = imread("")

# 	def roi()