import Navigation as nav
import cTypeMod as ctm
import mouseMov as msm
from time import sleep

class walk:

		# Navigation Values
		# 0 = fallback
		# 1 = go Straight
		# 2 = turn Left
		# 3 = turn Right
	def __init__(self,frame):
		n = nav.Navigation()
		cmd = n.getWalkCoords(frame)
		if (cmd == 1):
			ctm.ReleaseKey("s")
			print("W pressed")
			ctm.PressKey("w")
		elif(cmd == 0):
			ctm.ReleaseKey("w")
			for i in range(0,3):
				ctm.PressKey("s")
				sleep(0.1)
			msm.halfRotLeft()
		elif(cmd == 2):
			ctm.ReleaseKey("s")
			ctm.ReleaseKey("w")
			msm.halfRotLeft()
		elif(cmd == 3):
			ctm.ReleaseKey("s")
			ctm.ReleaseKey("w")
			msm.halfRotRight()