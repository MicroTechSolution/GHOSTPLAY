from cv2 import *
from PIL import ImageGrab
from time import *
import numpy as np
from Navigation import *


class Capturer:
    """docstring for capture"""
    Signal = False
    Framerate = 0
    def __init__(self, arg):
        self.Framerate = arg    

    def ChangeSignal():
        global Signal
        if Signal:
            Signal = False
        else:
            Signal = True


    def capture(self):
        #global Framerate
        time.sleep(0.02)
        img = ImageGrab.grab()
        img_gp = np.array(img)
        #All upcoming functions are Occurs here
        return (img_gp)










