import winreg as wr

REG_PATH = "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
file_name = "runAll.bat"
file_path = "\"E:\study\PythonProjects\GhostPlay\\"+ file_name+"\""
def makeBat():
	file = open(file_name,"w")
	file.write("e:\ncd study\PythonProjects\GhostPlay\npython gui05.py")
	print(file_path)
	file.close()

def createKey():
	#wr.CreateKey(wr.HKEY_CURRENT USER, REG_PATH)
	reg_key = wr.OpenKey(wr.HKEY_CURRENT_USER, REG_PATH, 0, wr.KEY_WRITE)
	wr.SetValueEx(reg_key,"GhosPlayGUI",0,wr.REG_SZ,file_path)
	print("here")
	wr.CloseKey(reg_key)

def removeKey():
	reg_key = wr.OpenKey(wr.HKEY_CURRENT_USER, REG_PATH, 0, wr.KEY_WRITE)
	wr.SetValueEx(reg_key,"GhosPlayGUI",0,wr.REG_SZ,"null")
	wr.CloseKey(reg_key)
