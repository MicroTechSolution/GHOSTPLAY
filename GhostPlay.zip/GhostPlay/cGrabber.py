import mouseMov as msm
import cTypeMod as ctm
import runVals as rv

class cgrab:
	def __init__(self,newMsg):


		index = 0
		temp = ""
		msg = ""
		readit = True
		newMsg = newMsg.replace(" ","")


		#MouseMovement
		if(newMsg.find("!!!") != -1):
			index == newMsg.find("!!!")
			index += 5
			while(newMsg[index] != "!"):
				msg += newMsg[index]
				index += 1

			msg = msg.split("x")
			self.mouseMsgs(msg)

		elif(newMsg.find("###") != -1):
			index == newMsg.find("###")
			index += 5
			while(newMsg[index] != "#"):
				msg += newMsg[index]
				index += 1
			self.keyMsgs(msg)
		

		print(msg)
		
	def mouseMsgs(self,pos):
		msm.moveCursor(int(pos[0]) * 2,int(pos[1]) * 2)

	def keyMsgs(self,msg):
		if(msg == "SENDWATCHBACK"):
			print("Watching back")
			msm.fullRotLeft()

		elif(msg == "SENDSHUTDOWNAI"):
			print("shutting down")
			ctm.PressKey("CTRL")
			ctm.PressKey("v")
			ctm.ReleaseKey("v")
			ctm.ReleaseKey("CTRL")

		elif(msg == "SENDCAMPONLY"):
			if(rv.startAI == True):
				rv.startAI = False
				print("Camping")
				ctm.PressKey("CTRL")
				ctm.PressKey("b")
				ctm.ReleaseKey("b")
				ctm.ReleaseKey("CTRL")

		elif(msg == "LEFTMOUSECLICK"):
			msm.click()
		elif(msg == "RIGHTMOUSECLICK"):
			msm.rightClick()

		elif(msg == "SENDSTARTAI"):
			rv.startAI = True

		elif(msg == "SENDENTERBTN"):
			ctm.PressKey("ENTER")
			ctm.ReleaseKey("ENTER")

		elif(msg == "SENDCOPYBTN"):
			ctm.PressKey("CTRL")
			ctm.PressKey("c")
			ctm.ReleaseKey("c")
			ctm.ReleaseKey("CTRL")

		elif(msg == "SENDPASTEBTN"):
			ctm.PressKey("CTRL")
			ctm.PressKey("v")
			ctm.ReleaseKey("v")
			ctm.ReleaseKey("CTRL")

		elif(msg == "SENDCUTBTN"):
			ctm.PressKey("CTRL")
			ctm.PressKey("x")
			ctm.ReleaseKey("x")
			ctm.ReleaseKey("CTRL")

		elif(msg == "SENDALTF4BTN"):
			ctm.PressKey("ALT")
			ctm.PressKey("F4")
			ctm.ReleaseKey("F4")
			ctm.ReleaseKey("ALT")


		elif(msg == "STUCK"):
			msm.fullRotLeft()

		elif(msg == "RELOADGUN"):
			pass
		elif(msg == "CHANGESECONDARY"):
			pass
		elif(msg == "FALLBACK"):
			pass
		elif(msg == "GOSLOWLY"):
			pass
		elif(msg == "CROUCHANDGO"):
			pass



if __name__ == '__main__':
	cg = cgrab("###")