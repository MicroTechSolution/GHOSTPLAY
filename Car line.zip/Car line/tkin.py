from tkinter import *

from tkinter import messagebox

top = Tk()
top.geometry("100x100")
def helloCallBack():
   msg = messagebox.showinfo( "AI gaming", "Script  is now Working")

X = Button(top, text = "Start", command = helloCallBack)
X.place(x = 70,y = 70)

Y = Button(top, text = "Pause", command = helloCallBack)
Y.place(x = 250,y = 70)

Z = Button(top, text = "Run", command = helloCallBack)
Z.place(x = 430,y = 70)
top.mainloop()
