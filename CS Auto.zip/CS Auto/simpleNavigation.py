from cv2 import *
import random

stepCount = [[0,0,0,0],[1,1,1,1],[2,2,2,2],[3,3,3,3]]
stepCountLast = 0

class SimpleNavigation:
	
	

	def roi(self,frame,side):

		#There are some problem in getting shape ie. sometime it sending 3 vals sometime 2 vals so we are taking in exception block
		wid = 0
		hei = 0
		try:
			wid, hei = frame.shape[:]
			#if required 3 valuse
		except Exception:
			hei,wid,_ = frame.shape[:]
		
		if side == "bottom":
			#now taking half of width
			wid = int(wid/2)
			# making center of roi upwards
			center = hei - 250
			#rectangle(frame,(wid-30,center-30),(wid+30,center+30),(255,0,0),2)
			#ROI
			frame = frame[(wid-30):(wid+30), (center-30): (center+30)]
			#imshow("bottom", frame)
			#now need creturn cropped area
			return frame

		elif side == "top":
			#now taking half of width
			wid = int(wid/2)
			# making center of roi upwards
			center = 0 + 200
			#rectangle(frame,(wid-30,center-30),(wid+30,center+30),(255,0,0),2)
			#ROI
			#imshow("top", frame)
			frame = frame[(wid-30):(wid+30), (center-30): (center+30)]
			#now need creturn cropped area
			return frame
		elif side == "left":
			hei = int(hei/2)
			center = 0 +200

			#rectangle(frame,(center-30,hei-30),(center+30,hei+30),(255,0,0),2)
			#imshow("top", frame)
			frame = frame[(center-30):(center+30), (hei-30): (hei+30)]
			#now need creturn cropped area
			return frame

		elif side == "right":
			hei = int(hei/2)
			center = wid -200

			#rectangle(frame,(center-30,hei-30),(center+30,hei+30),(255,0,0),2)
			#imshow("top", frame)
			frame = frame[(center-30):(center+30), (hei-30): (hei+30)]
			#now need creturn cropped area
			return frame

	def count(self,frame):
		wid,hei = frame.shape[:]
		#Here we count that how much pixels are white
		#we found that if count gets more than ~ 100-150 there is something front of us sometines
		count = 0
		for i in range(-1,hei-1):
			for j in range(-1,wid-1):
				if frame[i,j] == 255:
					count = count+1
		#print(count)
		return count

	def isOkToWalk(self,count):
		if count < 180:
			#print("we can walk further")
			return True
		else:
			#print("need Turn")
			return False

	def calculateMovement(self,left,right,top,bottom):
		#if Random.randint()
		if(self.isStuck(left,right,top,bottom) == False):
			if(bottom > 180):
				if(left>180 and right <180):
					return "TurnRight"
				elif(left<180 and right >180):
					return "TurnLeft"
				elif(left>180 and right >180):
					return "getBack"
				else:
					return "isOkToWalk"
			else:
				return "isOkToWalk"
		else:
			return "getBack"

	def isStuck(self,left,right,top,bottom):
		global stepCount,stepCountLast
		isEmpty = True
		status = 0

		for i in range(0,4):
			for j in range(0,4):
				if (stepCount[i][j] != i):
					isEmpty = False

		if isEmpty:
			stepCount[stepCountLast][0] = left
			stepCount[stepCountLast][1] = right
			stepCount[stepCountLast][2] = top
			stepCount[stepCountLast][3] = bottom
			stepCountLast += 1
			return False

		else:
			if stepCountLast == 4:
				for i in range(0,4):
					if(stepCount[0][i] == stepCount[1][i] and stepCount[0][i] == stepCount[2][i] and stepCount[0][i] == stepCount[3][i]):
						status += 1

				if(status > 2):
					for i in range(0,4):
						for j in range(0,4):
							stepCount[i][j] = i
							stepCountLast = 0
					return True

				else:
					for i in range(0,4):
						for j in range(0,4):
							stepCount[i][j] = i
							stepCountLast = 0
					return False
					#need to do calculate if all are same and reset all counters

			else:
				stepCount[stepCountLast][0] = left
				stepCount[stepCountLast][1] = right
				stepCount[stepCountLast][2] = top
				stepCount[stepCountLast][3] = bottom
				stepCountLast += 1
				return False

		#for i in range(0,4):
		#	for j in range(0,4):
		#		print(stepCount[i][j], " -- ", i, " ",j)
		#	print("--")		




	def navigate(self,frame):
		frame = cvtColor(frame,COLOR_BGR2GRAY)
		frame = GaussianBlur(frame,(3,3),0)
		#Thresh values checked = 100 is good
		_,frame = threshold(frame,100,255,THRESH_BINARY)
		frame = Canny(frame,200,300)

		left = self.count(self.roi(frame,"left"))
		right = self.count(self.roi(frame,"right"))
		top = self.count(self.roi(frame,"top"))
		bottom = self.count(self.roi(frame,"bottom"))

		return self.calculateMovement(left,right,top,bottom)



#if __name__ == "__main__":
#	cap = VideoCapture("vid1.mp4")
#	while 1:
#		_,frame = cap.read()
#		a = SimpleNavigation()
		#left = a.roi(frame,"left")

		

#		frame = cvtColor(frame,COLOR_BGR2GRAY)
		
#		frame = GaussianBlur(frame,(3,3),0)
		#Thresh values checked = 100 is good
#		_,frame = threshold(frame,100,255,THRESH_BINARY)
#		frame = Canny(frame,200,300)

		#imshow("left",a.roi(frame,"left"))
		#imshow("right",a.roi(frame,"right"))
		#imshow("top",a.roi(frame,"top"))
		#imshow("bottom",a.roi(frame,"bottom"))
		#imshow('img',frame)
		#roi(frame,1)

#		a.isOkToWalk(a.count(a.roi(frame,"bottom")))

#		if waitKey(1) & 0xFF == ord('q'):
#			break

#	cap.release()

#	sn = SimpleNavigation()
#	print(sn.isStuck(133,133,242,555))
#	print(sn.isStuck(133,133,242,555))
#	print(sn.isStuck(133,133,242,555))
#	print(sn.isStuck(133,133,242,555))
#	print(sn.isStuck(133,133,242,555))



