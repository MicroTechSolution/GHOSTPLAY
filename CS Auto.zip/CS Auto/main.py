from time import *
import simpleNavigation as snav
import mouseMov as msm
import capturer as capt
import cTypeMod as ctm
import random

class mainStart(object):
	"""docstring for mainStart"""
	def __init__(self):
		cap = capt.Capturer(0.02)
		sn = snav.SimpleNavigation()
		
		# capture from capturere and send it to navigate. navigate will return boolean value
		while 1:
			value = sn.navigate(cap.capture())
			print(value)
			self.moveMouse(value)

		
	def moveMouse(self,value):
		if value == "TurnLeft":
			ctm.ReleaseKey("W")
			sleep(1)
			msm.halfRotLeft()
		elif value == "TurnRight":
			ctm.ReleaseKey("W")
			sleep(1)
			msm.halfRotRight()
		elif value == "getBack":
			ctm.ReleaseKey("W")
			for i in range(0,10):
				print("Here")
				ctm.PressKey("S")
				sleep(0.1)
			ctm.ReleaseKey("S")
			if(random.randint(0,1) == 1):
				msm.halfRotLeft()
			else:
				msm.halfRotRight()
		else:
			ctm.ReleaseKey("S")
			ctm.PressKey("W")


mainStart()


