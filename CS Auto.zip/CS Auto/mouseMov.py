import ctypes
import time

# see http://msdn.microsoft.com/en-us/library/ms646260(VS.85).aspx for details
def pos(x, y):
    ctypes.windll.user32.SetCursorPos(x, y)

def click():
    #hex value required at 1st parameter
    #https://msdn.microsoft.com/en-us/library/windows/desktop/ms646260(v=vs.85).aspx

    ctypes.windll.user32.mouse_event(0x0008, 0, 0, 0,0) # left down
    ctypes.windll.user32.mouse_event(0x0010, 0, 0, 0,0) # left up

#From here we write our code


def halfRotLeft():
    for i in range(4):
        pos(100,384) #set half of the screen
        time.sleep(0.02)
    #This is 90 degree


def halfRotRight():
    for i in range(4):
        pos(1500,384) #set half of the screen
        time.sleep(0.02)

def smallRotLeft(x,y):
    x = int(x/2)
    y = y/2
    #for i in range(1):
    pos(x+600,384) #set half of the screen
    time.sleep(0.01)

def smallRotRight(x,y):
    x = int(x/2)
    y = y/2
    #for i in range(1):
    pos(x-600,384) #set half of the screen
    time.sleep(0.01)


#time.sleep(3)
#smallRotLeft(1920,1080)
