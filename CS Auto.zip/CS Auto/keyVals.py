def change(asa):
    asa = asa.upper()
    #0x57
    if(asa == "W"):
        return 0x57
    elif(asa == "up"):
        return 0x26
    elif (asa == "left"):
        return 0x01
    elif (asa == "Right"):
        return 0x02
    elif (asa == "Control-break processing"):
        return 0x03
    elif (asa == "Middle_M"):
        return 0x04
    elif (asa == "BACKSPACE"):
        return 0x08
    elif (asa == "TAB"):
        return 0x09
    elif (asa == "CLEAR"):
        return 0x0C
    elif (asa == "ENTER"):
        return 0x0D
    elif (asa == "SHIFT"):
        return 0x10
    elif (asa == "CTRL"):
        return 0x11
    elif (asa == "ALT"):
        return 0x12
    elif (asa == "PAUSE"):
        return 0x13
    elif (asa == "CAPS LOCK"):
        return 0x14
    elif (asa == "ESC"):
        return 0x1B
    elif (asa == "SPACEBAR"):
        return 0x20
    elif (asa == "PAGE UP"):
        return 0x21
    elif (asa == "PAGE DOWN "):
        return 0x22
    elif (asa == "END"):
        return 0x23
    elif (asa == "HOME"):
        return 0x24
    elif (asa == "LEFT ARROW"):
        return 0x25
    elif (asa == "UP ARROW"):
        return 0x26
    elif (asa == "RIGHT ARROW"):
        return 0x27
    elif (asa == "DOWN ARROW"):
        return 0x28
    elif (asa == "SELECT"):
        return 0x29
    elif (asa == "DEL"):
        return 0x2E
    elif (asa == "0"):
        return 0x30
    elif (asa == "1"):
        return 0x31
    elif (asa == "2"):
        return 0x32
    elif (asa == "3"):
        return 0x33
    elif (asa == "4"):
        return 0x34
    elif (asa == "5"):
        return 0x35
    elif (asa == "6"):
        return 0x36
    elif (asa == "7"):
        return 0x37
    elif (asa == "8"):
        return 0x38
    elif (asa == "9"):
        return 0x39
    elif (asa == "A"):
        return 0x41
    elif (asa == "B"):
        return 0x42
    elif (asa == "C"):
        return 0x43
    elif (asa == "D"):
        return 0x44
    elif (asa == "E"):
        return 0x45
    elif (asa == "F"):
        return 0x46
    elif (asa == "G"):
        return 0x47
    elif (asa == "H"):
        return 0x48
    elif (asa == "I"):
        return 0x49
    elif (asa == "J"):
        return 0x4A
    elif (asa == "K"):
        return 0x4B
    elif (asa == "L"):
        return 0x4C
    elif (asa == "M"):
        return 0x4D
    elif (asa == "N"):
        return 0x4E
    elif (asa == "O"):
        return 0x4F
    elif (asa == "P"):
        return 0x50
    elif (asa == "Q"):
        return 0x51
    elif (asa == "R"):
        return 0x52
    elif (asa == "S"):
        return 0x53
    elif (asa == "T"):
        return 0x54
    elif (asa == "U"):
        return 0x55
    elif (asa == "V"):
        return 0x56
    elif (asa == "W"):
        return 0x57
    elif (asa == "X"):
        return 0x58
    elif (asa == "Y"):
        return 0x59
    elif (asa == "Z"):
        return 0x5A
    elif (asa == "F1"):
        return 0x70
    elif (asa == "F2"):
        return 0x71
    elif (asa == "F3"):
        return 0x72
    elif (asa == "F4"):
        return 0x73
    elif (asa == "F5"):
        return 0x74
    elif (asa == "F6"):
        return 0x75
    elif (asa == "F7"):
        return 0x76
    elif (asa == "F8"):
        return 0x77
    elif (asa == "F9"):
        return 0x78
    elif (asa == "F10"):
        return 0x79
    elif (asa == "F11"):
        return 0x7A
    elif (asa == "F12"):
        return 0x7B
    elif (asa == "Left SHIFT"):
        return 0xA0
    elif (asa == "Right SHIFT"):
        return 0xA1
